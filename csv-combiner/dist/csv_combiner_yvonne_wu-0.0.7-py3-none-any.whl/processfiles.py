import csv
import pandas as pd
import os
path = 'csv-combiner/fixtures/'
with open('output.csv', 'w', newline='') as f_output:
    csv_output = csv.writer(f_output)

    for filename in glob.glob(os.path.join(path,"*.csv")):
        with open(filename, newline='') as f_input:
            csv_input = csv.reader(f_input)

            for row in csv_input:
                row.insert(0, filename)
                csv_output.writerow(row) 